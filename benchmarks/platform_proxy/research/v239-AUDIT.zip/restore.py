import hashlib,json,sys,zipfile
from pathlib import Path
archive=Path(__file__).resolve().with_name('v239-AUDIT.zip')
destination=Path(sys.argv[1]).resolve();destination.mkdir(parents=True,exist_ok=True)
with zipfile.ZipFile(archive) as z:
    manifest=json.loads(z.read('MANIFEST.sha256.json'))
    for name,digest in manifest.items():
        target=(destination/name).resolve()
        if not target.is_relative_to(destination):raise ValueError('Unsafe path')
        data=z.read('objects/'+digest)
        if hashlib.sha256(data).hexdigest()!=digest:raise ValueError('Hash mismatch')
        if target.exists() and target.read_bytes()!=data:raise FileExistsError(target)
        target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
print('Verified and restored',len(manifest),'files')
