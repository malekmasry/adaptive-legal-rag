"""Per-request accounting, isolated across concurrent CSV/chat requests."""
from __future__ import annotations

from contextvars import ContextVar
from dataclasses import dataclass, field
import hashlib
import json
import os
from time import perf_counter


# An absolute batch deadline is explicitly installed in each worker: contextvars
# are not automatically propagated to ThreadPoolExecutor threads.
DEADLINE: ContextVar[float | None] = ContextVar("rag_deadline", default=None)


def remaining_seconds(default: float = 60.0) -> float:
    deadline = DEADLINE.get()
    return max(0.0, deadline - perf_counter()) if deadline is not None else default


@dataclass
class Trace:
    started: float = field(default_factory=perf_counter)
    deadline_seconds: float = 180.0
    stage: str = "initial"
    calls: list[dict] = field(default_factory=list)
    events: list[dict] = field(default_factory=list)
    timings: dict[str, float] = field(default_factory=dict)

    def remaining(self) -> float:
        own = max(0.0, self.deadline_seconds - (perf_counter() - self.started))
        return min(own, remaining_seconds(own))

    def public(self) -> dict:
        return {
            "total_ms": round((perf_counter() - self.started) * 1000, 2),
            "timings_ms": {key: round(value, 2) for key, value in self.timings.items()},
            "api_calls": self.calls,
            "prompt_tokens": sum(call.get("prompt_tokens", 0) for call in self.calls),
            "completion_tokens": sum(call.get("completion_tokens", 0) for call in self.calls),
            "usage_complete": bool(self.calls) and all(call.get("usage_reported", False) for call in self.calls),
            "events": self.events,
        }


CURRENT: ContextVar[Trace | None] = ContextVar("rag_trace", default=None)


_EVENT_FIELDS = (
    "stage", "status", "type", "count", "source_ids", "irac_ok", "unknown_citations",
    "has_citations", "nonliteral_quotes", "quarantined_lines", "dense_used", "characters", "skipped_ids",
    "route", "threshold", "rerank_score", "dense_rerank_score",
)
_CAPTURE_FIELDS = (
    "schema", "stage", "attempt", "payload", "wire_body_utf8", "wire_body_sha256",
    "latest_question", "question_sha256", "sources", "sources_sha256", "sources_hash_encoding", "source_ids",
)


def capture_generator_request(body: bytes, attempt: int) -> None:
    """Snapshot actual HTTP JSON bytes without inspecting credentials/headers.

    METRICS_PATH opts in through the existing runner environment. Each worker
    owns a separate ContextVar Trace; the runner persists its events with the
    corresponding CSV id. No shared writer or extra filesystem I/O is added.
    Stored messages/body are never sanitized or rewritten: they are evidence
    of the request actually sent, and source text remains untrusted data.
    """
    trace = CURRENT.get()
    if not os.environ.get("METRICS_PATH", "").strip() or trace is None or trace.stage != "direct_generation":
        return
    try:
        wire = body.decode("utf-8")
        payload = json.loads(wire)
        user = next(message["content"] for message in reversed(payload["messages"])
                    if message.get("role") == "user")
        task = json.loads(user)
        question, sources = task["latest_question"], task["sources"]
        if not isinstance(question, str) or not isinstance(sources, list):
            return
        sources_json = json.dumps(sources, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
        trace.events.append({
            "schema": "generator-request-capture-v1", "stage": "generator_request", "attempt": attempt,
            "payload": payload, "wire_body_utf8": wire,
            "wire_body_sha256": hashlib.sha256(body).hexdigest(),
            "latest_question": question, "question_sha256": hashlib.sha256(question.encode("utf-8")).hexdigest(),
            "sources": sources, "sources_sha256": hashlib.sha256(sources_json.encode("utf-8")).hexdigest(),
            "sources_hash_encoding": "JSON UTF-8, ensure_ascii=False, sort_keys=True, separators=(',',':')",
            "source_ids": [source["id"] for source in sources],
        })
    except Exception:
        # Observability must never change a request or its error/retry behavior.
        # Missing captures are detectable in post-run validation; never fabricate
        # a partial payload or print exceptions that could contain source text.
        return


def public_events(events: list[dict]) -> list[dict]:
    """Keep normal operational fields and explicitly opted-in exact captures."""
    return [{key: event[key] for key in (
        _CAPTURE_FIELDS if event.get("schema") == "generator-request-capture-v1"
        and event.get("stage") == "generator_request" else _EVENT_FIELDS
    ) if key in event} for event in events]
