import csv
import hashlib
import io
import json
from pathlib import Path
import shutil
import subprocess
import zipfile

ROOT=Path(r'C:\Users\USRBGDY\Documents\Codex\2026-11-13\rjh')
REPO=Path(r'C:\Users\USRBGDY\.codex\worktrees\psb-retriever35-v8\adaptive-legal-rag')
W=ROOT/'work';OUT=ROOT/'outputs';RUN=W/'v108-v228-comparison'
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def sha(b):return hashlib.sha256(b).hexdigest()
def write(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
summary=read(RUN/'summary.json');answers=read(RUN/'all-answers.json');judgments=read(RUN/'judgments.json')
cases=read(RUN/'cases.json');reg=read(RUN/'regression-cases.json');runtimes=summary['runtime']
codes={};hashes={};probe_answers={}
for name in ('v108','v228'):
    codes[name]=subprocess.check_output(['git','rev-parse','codex/'+name],cwd=REPO,text=True).strip()
    raw=(W/(name+'.zip')).read_bytes();hashes[name]=sha(raw)
    assert hashes[name]==runtimes[name]['package_sha256']==runtimes[name+'_regression']['package_sha256']
    assert runtimes[name]['complete'] and runtimes[name+'_regression']['complete']
    assert not runtimes[name]['runtime_report']['error_counts'] and not runtimes[name+'_regression']['runtime_report']['error_counts']
    with zipfile.ZipFile(io.BytesIO(raw)) as z:
        assert z.testzip() is None
        for n in z.namelist():
            assert '/' not in n and '\\' not in n
            assert not any(x in n for x in ('test_','questions','knowledge-base','results'))
            assert z.read(n)==subprocess.check_output(['git','show',f'codex/{name}:focused-rag/{n}'],cwd=REPO),name+'/'+n
        assert set(z.read('requirements.txt').decode().splitlines())<=set((OUT/'psb-rag/allowed_requirements.txt').read_text().splitlines())
    shutil.copyfile(W/(name+'.zip'),OUT/(name+'.zip'))
    (OUT/(name+'.sha256.txt')).write_text(hashes[name]+'  '+name+'.zip\n',encoding='ascii')
    with (RUN/'generated'/(name+'_regression')/'submission.csv').open(encoding='utf8',newline='') as f:
        probe_answers[name]={r['id']:r['answer'] for r in csv.DictReader(f)}
with zipfile.ZipFile(W/'v108.zip') as x,zipfile.ZipFile(W/'v228.zip') as y:
    shared=['answer_guides.py','corpus_playbook.py','corpus_playbook.json','rule_drafts.py','settings.py','model_api.py','retrieval.py','corpus.py']
    assert all(x.read(n)==y.read(n) for n in shared)
context_stats={}
for name in ('v108','v228'):
    rows=[json.loads(x) for x in (RUN/'generated'/name/'cache/diagnostics.jsonl').read_text().splitlines()]
    rows=[r for r in rows if r['event']=='focused_answer']
    context_stats[name]={'evidence_tokens_sum':sum(r['context']['estimated_tokens'] for r in rows),
      'mean_evidence_tokens':sum(r['context']['estimated_tokens'] for r in rows)/len(rows),
      'skipped_relation_count':sum(not d['keep'] for r in rows for d in r['context'].get('relation_decisions',[])),
      'rows_with_skipped_relations':[r['request_id'] for r in rows if any(not d['keep'] for d in r['context'].get('relation_decisions',[]))],
      'prepared_drafts':sum(r.get('draft_origin')=='source_rules' for r in rows)}
comparison_analysis={
 'identical_final_answers':sum(answers['v108'][c['id']]==answers['v228'][c['id']] for c in cases),
 'same_case_scores':18,
 'score_differences':[
   {'id':'S12c','v108':0.625,'v228':0.5,'finding':'Both answers state the same correct threshold and edition; judge scoring differs.'},
   {'id':'S28c','v108':0.0,'v228':0.75,'finding':'v108 was zeroed in one round for a detail present verbatim in the corpus; v228 kept the shorter source-rule draft.'}],
 's28_source_check':{
   'filename':'законы__НК_ст112_действующая.txt',
   'quote':'3. Лицо, с которого взыскана налоговая санкция, считается подвергнутым этой санкции в течение 12 месяцев с момента вступления в законную силу решения суда или налогового органа.',
   'edition_filename':'законы__НК_ст114_действующая.txt',
   'edition_quote':'Пункт 3 изменен с 1 сентября 2026 г. - Федеральный закон от 28 ноября 2025\u00a0г. № 425-ФЗ',
   'finding':'The judge mistakes information absent from the short golden for fabrication. Corpus evidence and its token count were the same for S28 in both variants; relation metadata and review behavior differed. A causal score gain from relation filtering is not established.'},
 'diagnostic_only':{'v108_without_false_s28_zero':74.1875,'v228_recorded_score':74.625,
   'note':'Counterfactual calculation only; recorded judgments and headline score remain unchanged. No new judge calls.'},
 'conclusion':'The recorded difference is dominated by a false fabrication flag. One known 20-question development set cannot establish a robust quality improvement.'}
with zipfile.ZipFile(RUN/'knowledge-base.zip') as z:
    for prefix in ('','edition_'):
        item=comparison_analysis['s28_source_check']
        assert item[prefix+'quote'] in z.read(item[prefix+'filename']).decode('utf-8-sig')
details={'summary':summary,'source_commits':codes,'package_sha256':hashes,'context_stats':context_stats,
 'comparison_analysis':comparison_analysis,
 'base':'guided_v4 / codex/benchmark-tuned-rag; both variants keep its31 notes,18 plans and source-rule drafts',
 'manual_regression_review':{'v108':{'passed':10,'total':10},'v228':{'passed':10,'total':10},
    'method':'Assistant comparison of generated answers with source documents; not an additional paid judge score'},
 'cases':[{'id':c['id'],'question':c['question'],'golden':c['golden'],
    'answers':{n:answers[n][c['id']] for n in answers},'judgments':[r for r in judgments if r['id']==c['id']]} for c in cases],
 'regression_cases':[{**c,'answers':{n:probe_answers[n][c['id']] for n in probe_answers}} for c in reg]}
write(OUT/'v108-v228-results.json',details)
lines=['v108 / v228 — СРАВНЕНИЕ 15.11.2026','',
 'Общая база: последняя версия guided_v4 с31 подсказкой по12 документам,18 каркасами и программными черновиками. Это НЕ прежний focused_v5; его отдельная сборка сохранена.',
 'v108: юридический вывод идёт первым; обязательная отметка текущей даты перенесена в конец. Других изменений продукта относительно guided_v4 нет.',
 'v228: v108 плюс таблица5 связей с темой, затрагиваемым положением, условием применения и SHA256 обоих исходников. Автоматически добавляются только относящиеся к вопросу связи; при неизвестной теме, неизвестной связи или изменившемся тексте действует сохранение связи.',
 'Исходные попадания реранкера не удаляются. Связанные положения копируются дословно с условиями. Проверка проводится после локального расширения соседей и заменяет прежнее безусловное расширение в двух местах. Дата спецификации не заменяется датой доставки; условие изменения сохраняется и для вопросов до его границы.',
 '31 подсказка,18 каркасов, программные черновики, алгоритмы поиска/реранжирования и модели одинаковые. Новых подсказок по содержанию в этих вариантах нет.','',
 'РЕЗУЛЬТАТЫ ОДНОГО ПРОТОКОЛА']
for n in ('v108','v228'):
    s=summary['systems'][n]['common_evaluated'];rt=runtimes[n];reg_rt=runtimes[n+'_regression']
    lines.append(f'{n}: {s["score"]:.4f}/100; оценено общих {s["evaluated"]}/20; MR={s["match_rate"]:.6f}; WR={s["win_rate"]:.6f}; побед/поражений/ничьих {s["wins"]}/{s["losses"]}/{s["ties"]}.')
    lines.append(f' 20 вопросов: {rt["seconds"]:.3f}с снаружи, {rt["runtime_report"]["seconds"]:.3f}с внутри; дополнительные10: {reg_rt["seconds"]:.3f}с. Технических ошибок продукта нет. Проверки кода: '+('28' if n=='v108' else '36')+'.')
    lines.append(f' Средний объём evidence: {context_stats[n]["mean_evidence_tokens"]:.1f} токенов; пропущенных автоматических связей: {context_stats[n]["skipped_relation_count"]}; готовых черновиков: {context_stats[n]["prepared_drafts"]}.')
    lines.append(f' SHA256 ZIP: {hashes[n]}; код: {codes[n]}.')
lines.extend(['','ЧЕМ ОБЪЯСНЯЕТСЯ РАЗНИЦА',
 '18 из 20 оценок совпали; 12 ответов полностью идентичны. S12c: v108=0.625, v228=0.5 при одинаково верном выводе. S28c: v108=0, v228=0.75.',
 'На S28c судья в одном раунде ошибочно назвал выдумкой слова «решения суда или налогового органа» и дату вступления редакции. Обе детали прямо есть в исходниках НК_ст112/НК_ст114. Это зафиксированная ошибка локального судьи, а не установленная галлюцинация продукта.',
 'Исходные документы и их объём на S28c совпали. В v108 проверяющая модель расширила черновик, а в v228 сохранила короткий. Отличались метаданные контекста; отдельно влияние таблицы связей от вариативности LLM здесь не доказано.',
 'Только диагностически: если снять ложное обнуление S28c, оставив его исходную оценку 0.5, v108 получил бы 74.1875 вместо 69.7102. Официальный результат эксперимента не исправляется; повторных вызовов судьи ради улучшения оценки нет.',
 'Итог +4.9148 пункта в пользу v228 сильно зависит от ошибки судьи. Устойчивое преимущество качества на неизвестных вопросах этим прогоном не установлено.',
 '', 'МЕТОДИКА И ГРАНИЦЫ',
 'Те же20 известных development-вопросов, эталоны и сохранённый baseline. Судья DeepSeek с неизменённым team_score-протоколом: команда явно обозначается A/B, оценка команды запрашивается в обоих порядках. Формула100*(0.7MR+0.3WR). Выдумка в любом раунде обнуляет вопрос; ошибка судьи исключает вопрос. Это не официальный скор ПСБ.',
 'Совпадающие целиком ответы получают общий кэш судейства, чтобы одинаковый текст не оценивался по-разному лишь из-за повторного вызова. Для разных текстов оцениваются оба порядка. Эталоны и ответы baseline не попадают в продукт.',
 'Варианты запускались парами, каждый с3 потоками, через общий шлюз максимум3 одновременных API-вызова. Одинаковые запросы к реальному Qwen3-Reranker-8B используют общий кэш полного запроса; эмбеддинги BGE-M3 прогреты. Время включает конкуренцию и кэш, не является отдельным прогнозом времени на платформе.',
 'Для сопоставимости с исходным стендом AS_OF в обоих прогонах закреплён как2026-11-14. В продукте дата берётся из окружения либо текущей даты запуска.',
 'Дополнительные10 вопросов обоих вариантов проверены вручную по исходникам:10/10. Это целевые проверки новых формулировок, чисел, дат, инъекций и отсутствующих норм, а не независимый скрытый тест.',
 f'Весь эксперимент: {summary["seconds"]:.3f}с. Расход: DeepSeek {summary["usage"]["deepseek_calls"]} вызовов / {summary["usage"]["deepseek_tokens"]:,} reported tokens; Qwen {summary["usage"]["qwen_calls"]} вызовов / {summary["usage"]["qwen_input_tokens"]:,} input tokens; повторно использовано Qwen-ответов {summary["usage"]["qwen_cache_hits"]}.',
 'Генератор/судья — только пользовательский DeepSeek API; Qwen — только отдельный Qwen API. Стоимость в валюте не подсчитывается. Официальная отправка не выполнялась; выбор сабмита остаётся за пользователем.',
 '', 'v108.zip и v228.zip — два отдельных плоских сабмита. v108-v228-AUDIT.zip — исследовательский архив, НЕ загружать как сабмит. Полные ответы и объяснения судьи: v108-v228-results.json.'])
(OUT/'v108-v228-report.txt').write_text('\n'.join(lines)+'\n',encoding='utf-8-sig')
public=REPO/'reports/v108-v228';public.mkdir(parents=True,exist_ok=True)
write(public/'summary.json',{k:v for k,v in details.items() if k not in ('cases','regression_cases')})
shutil.copyfile(OUT/'v108-v228-report.txt',public/'report.txt')
shutil.copyfile(OUT/'v108-v228-results.json',public/'results.json')
for n in ('v108','v228'):shutil.copyfile(W/(n+'-tests.log'),public/(n+'-tests.txt'))
shutil.copyfile(W/'v108-v228-offline-context.json',public/'context-comparison.json')
secrets=[]
def collect(v):
    if isinstance(v,dict):
        for k,x in v.items():
            if 'key' in k.lower() and isinstance(x,str) and len(x)>10:secrets.append(x.encode())
            collect(x)
    elif isinstance(v,list):
        for x in v:collect(x)
for n in ('local_api.json','siliconflow-reranker.private.json','platform-proxy-services.private.json'):collect(read(W/n))
def scan(data,name):
    assert not any(s in data for s in secrets),'Secret in '+name
    if name.endswith('.zip'):
        with zipfile.ZipFile(io.BytesIO(data)) as z:
            for n in z.namelist():scan(z.read(n),name+'/'+n)
entries={n:(OUT/n).read_bytes() for n in ('v108.zip','v228.zip','v108-v228-results.json','v108-v228-report.txt')}
for p in RUN.rglob('*'):
    if not p.is_file() or '__pycache__' in p.parts:continue
    rel=p.relative_to(RUN)
    if rel.parts[0]=='generated' and p.name not in ('submission.csv','submission.report.json','execution.json','diagnostics.jsonl','stdout.txt','stderr.txt'):continue
    if p.suffix in ('.sqlite3','.npz'):continue
    entries['run/'+rel.as_posix()]=p.read_bytes()
for folder in ('focused-rag','benchmarks/platform_proxy','reports/v108-v228'):
    for p in (REPO/folder).iterdir():
        if p.is_file():entries['code/'+folder+'/'+p.name]=p.read_bytes()
for n in ('build_focused_submission.py','build_relation_scope.py'):entries['code/'+n]=(REPO/n).read_bytes()
entries['package_v108_v228.py']=Path(__file__).read_bytes()
for n,b in entries.items():scan(b,n)
manifest={n:sha(b) for n,b in entries.items()};entries['MANIFEST.sha256.json']=json.dumps(manifest,indent=2).encode()
file=OUT/'v108-v228-AUDIT.zip'
with zipfile.ZipFile(file,'w',zipfile.ZIP_DEFLATED) as z:
    for n,b in entries.items():z.writestr(n,b)
with zipfile.ZipFile(file) as z:
    assert z.testzip() is None
    assert all(sha(z.read(n))==digest for n,digest in manifest.items())
print(json.dumps({'systems':summary['systems'],'usage':summary['usage'],'hashes':hashes,'context_stats':context_stats,'secret_scan':'passed'},ensure_ascii=False))
