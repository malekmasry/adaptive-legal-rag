import csv
import hashlib
import io
import json
from pathlib import Path
import shutil
import subprocess
import zipfile

ROOT=Path(r'C:\Users\USRBGDY\Documents\Codex\2026-11-13\rjh')
REPO=Path(r'C:\Users\USRBGDY\.codex\worktrees\psb-retriever35-v8\adaptive-legal-rag')
W=ROOT/'work';OUT=ROOT/'outputs';RUN=W/'v229-final-comparison';PARENT=W/'v108-v228-comparison';PRIOR=W/'v229-v228-comparison'
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def write(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
def sha(b):return hashlib.sha256(b).hexdigest()
summary=read(RUN/'summary.json');answers=read(RUN/'all-answers.json');judgments=read(RUN/'judgments.json')
preliminary=read(PRIOR/'summary.json')
combined_usage={k:summary['usage'][k]+preliminary['usage'][k] for k in summary['usage']}
cases=read(RUN/'cases.json');extra=read(RUN/'extension-cases.json');reg=read(RUN/'regression-cases.json')
review=read(W/'v229-manual-review.json')
source_commit=subprocess.check_output(['git','rev-parse','codex/v229'],cwd=REPO,text=True).strip()
blob=(W/'v229.zip').read_bytes();digest=sha(blob)
for name,r in summary['runtime'].items():
    assert r['complete'] and r['exit_code']==0 and not r['runtime_report']['error_counts']
    if name.startswith('v229'):assert r['package_sha256']==digest
with zipfile.ZipFile(io.BytesIO(blob)) as z:
    assert z.testzip() is None
    assert set(z.read('requirements.txt').decode().splitlines())<=set((OUT/'psb-rag/allowed_requirements.txt').read_text().splitlines())
    for n in z.namelist():
        assert '/' not in n and '\\' not in n
        assert not any(x in n for x in ('test_','questions','knowledge-base','results'))
        assert z.read(n)==subprocess.check_output(['git','show','codex/v229:focused-rag/'+n],cwd=REPO),n
with zipfile.ZipFile(W/'v228.zip') as x,zipfile.ZipFile(W/'v229.zip') as y:
    unchanged=['settings.py','model_api.py','retrieval.py','corpus.py','focused_context.py','relation_scope.py','relation_scope.json','rule_drafts.py','solution.py','requirements.txt']
    assert all(x.read(n)==y.read(n) for n in unchanged)
shutil.copyfile(W/'v229.zip',OUT/'v229.zip');(OUT/'v229.sha256.txt').write_text(digest+'  v229.zip\n',encoding='ascii')
context={}
for name in summary['runtime']:
    rows=[r for r in map(json.loads,(RUN/'generated'/name/'cache/diagnostics.jsonl').read_text().splitlines()) if r['event']=='focused_answer']
    context[name]={'rows':len(rows),'mean_source_tokens':sum(r['context']['estimated_tokens'] for r in rows)/len(rows),
      'mean_hint_tokens':sum(r['context']['verified_hint_tokens'] for r in rows)/len(rows),
      'active_hints_by_id':{r['request_id']:r['context']['verified_hint_count'] for r in rows},
      'prepared':sum(r.get('draft_origin')=='source_rules' for r in rows),
      'preserved':sum(bool(r.get('draft_preserved')) for r in rows)}
details={'summary':summary,'source_commit':source_commit,'package_sha256':digest,
 'preliminary_summary':preliminary,'combined_v229_stage_usage':combined_usage,
 'source_recovery_audit':read(W/'v229-recovery-audit.json'),
 'notes_audit':read(W/'v229-note-audit.json'),'manual_review':review,'context':context,
 'cases':[{'id':c['id'],'question':c['question'],'golden':c['golden'],
   'answers':{n:answers[n][c['id']] for n in ('v228','v229')},
   'judgments':[r for r in judgments if r['id']==c['id']]} for c in cases],
 'regression_cases':[{**c,'answer':answers['v229_regression'][c['id']]} for c in reg],
 'extension_cases':[{**c,'answers':{n:answers[n][c['id']] for n in ('v228_extension','v229_extension')},
   'judgments':[r for r in judgments if r['id']==c['id']]} for c in extra]}
write(OUT/'v229-v228-results.json',details)
lines=['v229 против v228 — 15.11.2026','',
 'v229 основана на проверенной v228. 107 подсказок вместо 31, все 21 исходников вместо 12; 35 типов ответа вместо 18. Подсказки выбирает код по теме и дополнительным признакам, проверяет SHA256 документа и видимые основания. В промпт попадают только прошедшие проверку; лимит памятки 2500 токенов внутри прежнего общего бюджета 18000.',
 'Из уже найденных документов могут добавляться точные подтверждающие фрагменты, если они потерялись при сборке большого контекста. Все недостающие основания одной подсказки должны поместиться целиком. На восстановление не более 1800 токенов из прежнего резерва 3500, разделённого с подсказками/карточками. Общий бюджет не увеличен. Для специальной налоговой ставки отдельный план; отрицание убытков не включает самостоятельную тему возмещения.',
 'Поиск, Qwen, таблица связей, программные черновики, транспорт и число стадий LLM сохранены. Проверяющему усилено указание сохранять правильный краткий ответ. Новых зависимостей нет.',
 '45 тестов кода пройдены. Все 107 подсказок имеют точные основания и отключаются при изменении исходника. Это проверка привязки, а не доказательство полноты всех возможных юридических ответов.','',
 'ПРЕЖНИЕ 20 ВОПРОСОВ: ОБЩИЙ СОХРАНЁННЫЙ BASELINE']
for name in ('v228','v229'):
    s=summary['systems'][name]['common_evaluated']
    lines.append(f'{name}: {s["score"]:.4f}/100; MR={s["match_rate"]:.6f}; WR={s["win_rate"]:.6f}; побед/поражений/ничьих {s["wins"]}/{s["losses"]}/{s["ties"]}; общих оценено {s["evaluated"]}/20.')
e=summary['extension_v229_vs_v228']
lines.extend(['19 из 20 оценок совпали. Единственное изменение — S12c: 0.5 → 0.625 при одинаково правильном выводе о согласовании. Прибавка 0.4375 пункта мала и сама по себе не доказывает устойчивого улучшения.',
 '', 'НОВЫЕ 12 ВОПРОСОВ ПО РАСШИРЕННЫМ ПОДСКАЗКАМ',
 f'Здесь baseline — свежие ответы v228, команда — v229: {e["score"]:.4f}/100; MR={e["match_rate"]:.6f}; WR={e["win_rate"]:.6f}; побед/поражений/ничьих {e["wins"]}/{e["losses"]}/{e["ties"]}; оценено {e["evaluated"]}/12.',
 'Конкретные победы: E03 (ставка НДС22%) — 1.0; E05 (IT5% федеральная+0% региональная) — 1.0; E12 (условия допуска сверх120 часов для вредности3.2) — 0.625. Первые две устраняют реальные пробелы ответа, третья отражает предпочтение судьи между правильными ответами.',
 'Этот показатель нельзя напрямую сопоставлять с баллом старых 20 вопросов: другой набор и другой baseline. Вопросы составлены по исходникам после первоначального расширения подсказок и зафиксированы до первой генерации. На найденных ошибках поправлены сборка источников и план ответа, после чего все 42 ответа v229 получены заново. Это development-тест, не скрытая независимая выборка.',
 '', 'ВРЕМЯ И РАСХОД'])
for name,r in summary['runtime'].items():lines.append(f'{name}: {r["seconds"]:.3f}с; статусы {json.dumps(r["runtime_report"]["counts"],ensure_ascii=False)}; технических ошибок нет.')
lines.extend([f'Весь текущий эксперимент с прогревом и судейством: {summary["seconds"]:.3f}с.',
 'Старые 20/10 ответов v228 не генерировались повторно. Время v228 на 20 вопросах ранее 158.625с получено при парном запуске; v229 на старом наборе запускалась отдельно. Из этих времён нельзя вывести причинное ускорение продукта.',
 f'Только текущий этап: DeepSeek {summary["usage"]["deepseek_calls"]} вызовов / {summary["usage"]["deepseek_tokens"]:,} reported tokens; Qwen {summary["usage"]["qwen_calls"]} вызовов / {summary["usage"]["qwen_input_tokens"]:,} input tokens; точных Qwen cache hits {summary["usage"]["qwen_cache_hits"]}.',
 f'Предварительная v229: {preliminary["systems"]["v229"]["common_evaluated"]["score"]:.4f}/100 на старых20; {preliminary["extension_v229_vs_v228"]["score"]:.4f}/100 относительно v228 на новых12. Обнаружены потерянный п.3 ст.164 и ошибочная общая ставка вместо IT. Этот неудачный результат сохранён полностью.',
 f'Весь этап v229, включая предварительную попытку: DeepSeek {combined_usage["deepseek_calls"]} вызовов / {combined_usage["deepseek_tokens"]:,} reported tokens; Qwen {combined_usage["qwen_calls"]} вызовов / {combined_usage["qwen_input_tokens"]:,} input tokens. Два эксперимента суммарно {summary["seconds"]+preliminary["seconds"]:.3f}с, без времени разработки.',
 '', 'РУЧНАЯ ПРОВЕРКА И ОБЪЯСНЕНИЕ РАЗНИЦЫ',json.dumps(review,ensure_ascii=False,indent=2),
 '', 'ГРАНИЦЫ СРАВНЕНИЯ',
 'Неизменённый DeepSeek team_score-судья, два порядка A/B, 100*(0.7MR+0.3WR), выдумка по флагу судьи в любом раунде обнуляет вопрос. Ошибки судьи исключаются. Все сырые решения сохранены, даже ошибочные. Идентичные полные входы судейства используют предыдущий результат, без выбора удачного повторного вызова.',
 'Генератор и судья обращались только к пользовательскому DeepSeek, Qwen3-Reranker-8B только к отдельному Qwen API. BGE-M3 локальный, новая ревизия модели не подменяется. В тесте AS_OF=2026-11-14 для сопоставимости; продукт использует окружение/дату запуска.',
 'Результаты локальные, не прогноз платформы. Официальная отправка не выполнялась.',
 f'v229.zip SHA256 {digest}; исходный коммит {source_commit}.',
 'v229-v228-AUDIT.zip — архив исследования, не сабмит. Сабмит только v229.zip либо ранее сохранённый v228.zip.'])
(OUT/'v229-v228-report.txt').write_text('\n'.join(lines)+'\n',encoding='utf-8-sig')
public=REPO/'reports/v229-v228';public.mkdir(parents=True,exist_ok=True)
for src,dst in [(OUT/'v229-v228-results.json','results.json'),(OUT/'v229-v228-report.txt','report.txt'),(W/'v229-tests.log','unit-tests.txt'),(W/'v229-note-audit.json','note-audit.json')]:shutil.copyfile(src,public/dst)
write(public/'summary.json',{k:v for k,v in details.items() if k not in ('cases','regression_cases','extension_cases')})
secrets=[]
def collect(v):
    if isinstance(v,dict):
        for k,x in v.items():
            if 'key' in k.lower() and isinstance(x,str) and len(x)>10:secrets.append(x.encode())
            collect(x)
    elif isinstance(v,list):
        for x in v:collect(x)
for n in ('local_api.json','siliconflow-reranker.private.json','platform-proxy-services.private.json'):collect(read(W/n))
def scan(data,name):
    assert not any(s in data for s in secrets),'Secret in '+name
    if name.endswith('.zip'):
        with zipfile.ZipFile(io.BytesIO(data)) as z:
            for n in z.namelist():scan(z.read(n),name+'/'+n)
entries={n:(OUT/n).read_bytes() for n in ('v229.zip','v228.zip','v229-v228-results.json','v229-v228-report.txt')}
for folder,prefix in ((RUN,'run/'),(PRIOR,'preliminary-run/')):
    for p in folder.rglob('*'):
        if not p.is_file() or '__pycache__' in p.parts:continue
        rel=p.relative_to(folder)
        if rel.parts[0]=='generated' and p.name not in ('submission.csv','submission.report.json','execution.json','diagnostics.jsonl','stdout.txt','stderr.txt'):continue
        if p.suffix in ('.sqlite3','.npz'):continue
        entries[prefix+rel.as_posix()]=p.read_bytes()
for directory,prefix in [(REPO/'focused-rag','code/focused-rag'),(public,'reports'),(W/'v229-benchmark-code/benchmarks/platform_proxy','code/benchmarks/platform_proxy')]:
    for p in directory.iterdir():
        if p.is_file():entries[prefix+'/'+p.name]=p.read_bytes()
for n in ('build_corpus_playbook.py','build_focused_submission.py','corpus_notes_v229.py','build_relation_scope.py'):entries['code/'+n]=(REPO/n).read_bytes()
entries['package_v229.py']=Path(__file__).read_bytes()
for n,b in entries.items():scan(b,n)
manifest={n:sha(b) for n,b in entries.items()};entries['MANIFEST.sha256.json']=json.dumps(manifest,indent=2).encode()
file=OUT/'v229-v228-AUDIT.zip'
with zipfile.ZipFile(file,'w',zipfile.ZIP_DEFLATED) as z:
    for n,b in entries.items():z.writestr(n,b)
with zipfile.ZipFile(file) as z:
    assert z.testzip() is None and all(sha(z.read(n))==v for n,v in manifest.items())
print(json.dumps({'sha256':digest,'systems':summary['systems'],'extension':e,'usage':summary['usage'],'secret_scan':'passed'},ensure_ascii=False))
