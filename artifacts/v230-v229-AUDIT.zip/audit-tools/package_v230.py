import hashlib,io,json,shutil,subprocess,zipfile
from pathlib import Path
BASE=Path(r'C:\Users\USRBGDY\Documents\Codex\2026-11-13\rjh')
REPO=Path(r'C:\Users\USRBGDY\.codex\worktrees\psb-retriever35-v8\adaptive-legal-rag')
W=BASE/'work';OUT=BASE/'outputs';RUN=W/'v230-comparison';FINAL=W/'v230-finalization'
read=lambda p:json.loads(p.read_text(encoding='utf8'))
sha=lambda b:hashlib.sha256(b).hexdigest()
def write(p,obj):p.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n',encoding='utf8')

summary=read(FINAL/'summary.json');freeze=read(RUN/'freeze.json');final_freeze=read(FINAL/'freeze.json')
commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip()
assert all(r['complete'] and r['exit_code']==0 and not r['runtime_report']['error_counts'] for r in summary['runtime'].values())
archive=(W/'v230-final.zip').read_bytes();digest=sha(archive)
assert digest==final_freeze['final_package_sha256']
assert sha((W/'v230.zip').read_bytes())==freeze['packages']['v230']['sha256']==final_freeze['generation_package_sha256']
with zipfile.ZipFile(io.BytesIO(archive)) as z:
    assert z.testzip() is None
    for n in z.namelist():
        assert Path(n).name==n and not n.startswith('test_') and 'private' not in n and 'cases' not in n
        assert z.read(n)==(REPO/'focused-rag'/n).read_bytes(),n
    allowed=set((OUT/'psb-rag/allowed_requirements.txt').read_text(encoding='utf8').splitlines())
    requirements=set(z.read('requirements.txt').decode().splitlines())
    assert requirements<=allowed,(requirements-allowed)
shutil.copyfile(W/'v230-final.zip',OUT/'v230.zip')
(OUT/'v230.sha256.txt').write_text(digest+'  v230.zip\n',encoding='ascii')
(REPO/'submissions').mkdir(exist_ok=True);shutil.copyfile(W/'v230-final.zip',REPO/'submissions/v230.zip')
details={'summary':summary,'freeze':freeze,'finalization_freeze':final_freeze,'cases':[{k:c[k] for k in ['id','question','golden']} for c in read(RUN/'cases.json')],'extension_cases':read(RUN/'extension-cases.json'),
 'extra_cases':read(RUN/'extra-cases.json'),'regression_cases':read(RUN/'regression-cases.json'),
 'answers':read(FINAL/'all-answers.json'),'judgments':read(FINAL/'judgments.json'),
 'manual_review':read(W/'v230-manual-review.json'),'offline_pipeline':read(W/'v230-offline-pipeline.json'),
 'source_commit':commit,'submission_sha256':digest,'platform_reference':{'version':'v229','score':35.5,'seconds':258,'provenance':'User report; per-question platform logs unavailable'}}
write(OUT/'v230-v229-results.json',details)
lines=['v230 против v229 — 15.11.2026','',
 'Рабочая база: v229. Пользователь сообщил результат платформы35,5/100 и258 секунд. У v230 официального результата ещё нет.',
 'Изменения:43 типа ответа;128 проверенных памяток; независимый поиск по316 структурным фрагментам всех21 документов и заранее написанным вариантам вопросов. Индекс хранит смещения и SHA256, тексты берёт из подключённой базы. Чужой/изменённый документ не получает статическую подсказку.',
 'Точные основания справочника получают до6000 токенов внутри прежнего18000-токенного бюджета. Расчёты до1100 токенов делят прежний резерв3500 с памятками/карточками. Сохраняются исходные документы и команды-инъекции в них как недоверенные данные.',
 'Независимое распознавание подвопросов и снятие противоречащих запретов между темами. Decimal-расчёты пеней с пределом, аренды, двух шкал НДФЛ, отдельных налоговых санкций и строгих порогов согласования. Исправлен множитель в суммах вроде12 миллионов рублей. Новых модельных стадий и зависимостей нет.',
 '65 тестов продукта и 16 тестов бенчмарка пройдены. 62 строки офлайн-проверки исполнения: уникальные источники/ссылки, отсутствие golden во входах продукта, сохранение бюджета 18000. Офлайн-проверка не измеряет качество модели.',
 'Основной живой прогон: 62 ответа v230 и 20 новых ответов v229, без технических ошибок продукта. Финальный ZIP отличается только чистым форматированием после завершённой проверки: доказуемая ссылка на примечание и точный незапрошенный раздел готового шаблона. Все 62 ответа воспроизведены с теми же источниками/бюджетами; изменились 2 текста, заново оценены в обоих порядках. Остальные 60 ответов идентичны; повторной полной платной генерации не было.',
 'Существенный выигрыш качества не доказан: прежние20 дают +0,4375 балла, новые20 — 1 победу, 1 поражение и 18 ничьих. Это не прогноз скрытой оценки ПСБ.','',
 'ПРЕЖНИЕ20: ОБЩИЙ СОХРАНЁННЫЙ BASELINE']
for name,v in summary['systems'].items():
    m=v['aggregate'];lines.append(f"{name}: {m['score']:.4f}/100; MR={m['match_rate']:.6f}; WR={m['win_rate']:.6f}; побед/поражений/ничьих {m['wins']}/{m['losses']}/{m['ties']}; оценено{m['evaluated']}; fabrication zeros={v['fabrication_zeros']}.")
lines+=['','ПРЯМОЕ СРАВНЕНИЕ С v229: ДРУГОЙ BASELINE']
for group,v in summary['direct_comparisons'].items():
    lines.append(f"{group}: {v['score']:.4f}/100; побед/поражений/ничьих {v['wins']}/{v['losses']}/{v['ties']}; оценено{v['evaluated']}.")
lines+=['extension — прежние 12 предметных вопросов; E12 исключён из-за ошибки валидации ответа судьи (не ошибка продукта), повторно без изменения ответа не оценивался. extra — 20 новых составных и перефразированных, зафиксированных до живой генерации. Все являются development-наборами. Баллы с разными baseline не смешиваются.','', 'ВРЕМЯ И РАСХОД']
for n,r in summary['runtime'].items():lines.append(f"{n}: {r['seconds']}с; {r['rows']} строк; статусы{r['runtime_report']['counts']}; ошибок{r['runtime_report']['error_counts']}.")
lines += [f"Основной эксперимент с локальным прогревом BGE, v229 и судейством: {summary['seconds']} с. Финальная проверка: {summary['finalization']['seconds']} с. Суммарно: {summary['seconds']+summary['finalization']['seconds']:.3f} с.",
 'Исполнение четырёх партий v230 (62 вопроса): 451,953 с; это сумма отдельных партий, не один непрерывный прогон. Прогрев BGE: 225,469 с. Qwen для v230 использовал точный кеш; вывод об ускорении на платформе не делается.',
 json.dumps(summary['total_usage'],ensure_ascii=False),summary['timing_note'],
 'Генератор и судья — DeepSeek через пользовательский API; Qwen3-Reranker-8B — через отдельный API. Модельные роли проверяются кодом. BGE-M3 с зафиксированной ревизией локально; runtime сабмита работает с API платформы.',
 'Неизменённый судья, два порядка A/B;100*(0.7MR+0.3WR), выдумка обнуляет вопрос, ошибки судьи исключаются. Полные совпадающие запросы судейства и Qwen могут использовать сохранённый результат. Повторный выбор удачной оценки не выполнялся.',
 'AS_OF локального сравнения2026-11-14 сохранён для сопоставимости с v229; продукт получает дату из окружения/даты запуска.','', 'РУЧНОЙ РАЗБОР',json.dumps(details['manual_review'],ensure_ascii=False,indent=2),'',
 f'v230.zip SHA256 {digest}. Исходный коммит {commit}.', 'v230-v229-AUDIT.zip — исследовательский архив, не сабмит. Для платформы: v230.zip.']
(OUT/'v230-v229-report.txt').write_text('\n'.join(lines)+'\n',encoding='utf-8-sig')
public=REPO/'reports/v230-v229';public.mkdir(parents=True,exist_ok=True)
for src,dst in [(OUT/'v230-v229-results.json','results.json'),(OUT/'v230-v229-report.txt','report.txt'),(W/'v230-final-tests.log','unit-tests.txt'),(W/'v230-benchmark-tests.log','benchmark-tests.txt'),(W/'v230-offline-pipeline.json','offline-pipeline.json'),(W/'v230-offline-decision-audit.json','decision-audit.json')]:shutil.copyfile(src,public/dst)
write(public/'summary.json',{'summary':summary,'manual_review':details['manual_review'],'source_commit':commit,'submission_sha256':digest,'platform_reference':details['platform_reference']})
secrets=[]
def collect(v):
    if isinstance(v,dict):
        for k,x in v.items():
            if 'key' in k.lower() and isinstance(x,str) and len(x)>10:secrets.append(x.encode())
            collect(x)
    elif isinstance(v,list):
        for x in v:collect(x)
for n in ['local_api.json','siliconflow-reranker.private.json','platform-proxy-services.private.json']:collect(read(W/n))
def scan(b,name):
    assert not any(s in b for s in secrets),'Secret in '+name
    if name.endswith('.zip'):
        with zipfile.ZipFile(io.BytesIO(b)) as z:
            for n in z.namelist():scan(z.read(n),name+'/'+n)
entries={n:(OUT/n).read_bytes() for n in ['v230.zip','v229.zip','v230-v229-results.json','v230-v229-report.txt']}
entries['run-packages/v230-generation.zip']=(W/'v230.zip').read_bytes()
for p in RUN.rglob('*'):
    if not p.is_file() or '__pycache__' in p.parts or p.suffix in ['.sqlite3','.npz']:continue
    rel=p.relative_to(RUN)
    if rel.parts[0]=='generated' and p.name not in ['submission.csv','submission.report.json','execution.json','diagnostics.jsonl','stdout.txt','stderr.txt']:continue
    entries['run/'+rel.as_posix()]=p.read_bytes()
for p in FINAL.rglob('*'):
    if p.is_file() and '__pycache__' not in p.parts and p.suffix not in ['.sqlite3','.npz']:
        entries['finalization/'+p.relative_to(FINAL).as_posix()]=p.read_bytes()
for folder,prefix in [(REPO/'focused-rag','code/focused-rag'),(W/'v230-benchmark-code/benchmarks/platform_proxy','code/benchmarks/platform_proxy'),(public,'reports')]:
    for p in folder.iterdir():
        if p.is_file():entries[prefix+'/'+p.name]=p.read_bytes()
for n in ['build_corpus_playbook.py','build_decision_catalog.py','build_focused_submission.py','corpus_notes_v229.py','corpus_notes_v230.py','build_relation_scope.py','README.md','VERSION.txt']:entries['code/'+n]=(REPO/n).read_bytes()
for n in ['prepare_v230_cases.py','v230-extra-cases.sha256','v230-offline-pipeline.json','package_v230.py','finalize_v230.py','v230-manual-review.json','refresh_v230_audit.py']:entries['audit-tools/'+n]=(W/n).read_bytes()
for n,b in entries.items():scan(b,n)
manifest={n:sha(b) for n,b in entries.items()};entries['MANIFEST.sha256.json']=json.dumps(manifest,indent=2).encode()
file=OUT/'v230-v229-AUDIT.zip'
with zipfile.ZipFile(file,'w',zipfile.ZIP_DEFLATED) as z:
    for n,b in entries.items():z.writestr(n,b)
with zipfile.ZipFile(file) as z:assert z.testzip() is None and all(sha(z.read(n))==s for n,s in manifest.items())
print(json.dumps({'submission_sha256':digest,'source_commit':commit,'audit_bytes':file.stat().st_size,'secret_scan':'passed','systems':summary['systems'],'direct':summary['direct_comparisons'],'usage':summary['total_usage']},ensure_ascii=False))
