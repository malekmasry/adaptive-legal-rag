"""Replay the final final formatting operations on every frozen v230 answer.

Generation and reviewer inputs are byte-equivalent: the new runtime differs
only by a pure formatter after final review. Rejudge only changed output text.
"""
import contextlib,hashlib,io,json,shutil,sys,tempfile,time,zipfile
from pathlib import Path
BASE=Path(__file__).resolve().parent
RUN=BASE/'v230-comparison';OUT=BASE/'v230-finalization'
REPO=Path(r'C:\Users\USRBGDY\.codex\worktrees\psb-retriever35-v8\adaptive-legal-rag')
read=lambda p:json.loads(p.read_text(encoding='utf8'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
started=time.monotonic()
original=BASE/'v230.zip';final=BASE/'v230-final.zip'
with zipfile.ZipFile(original) as before,zipfile.ZipFile(final) as after:
    assert set(after.namelist())-set(before.namelist())=={'citation_labels.py'}
    for n in before.namelist():
        if n!='pipeline.py':assert before.read(n)==after.read(n),n
    code=after.read('pipeline.py').decode('utf8').replace('\r\n','\n')
    code=code.replace('from citation_labels import finish_answer\n','')
    code=code.replace('        answer=finish_answer(answer,query,refs,evidence,self.docs)\n','')
    assert code==before.read('pipeline.py').decode('utf8').replace('\r\n','\n'),'Generation path changed; cannot replay a output-only formatting patch'
if OUT.exists():raise SystemExit('Finalization exists; refusing blind rerun')
OUT.mkdir()
sys.path.insert(0,str(REPO/'focused-rag'))
from pipeline import Pipeline
from settings import Settings
from citation_labels import finish_answer
class Captured(Exception):
    def __init__(self,payload):self.payload=payload
class Intercept:
    def structured(self,instruction,payload,schema):raise Captured(payload)
    def close(self):pass
all_answers=read(RUN/'all-answers.json');changes=[];replay=[]
with tempfile.TemporaryDirectory() as temp:
    core=Pipeline(Settings(data_dir=RUN,cache_dir=Path(temp),context_tokens=18000,as_of='2026-11-14'),Intercept())
    chunk_map={c.id:c for c in core.all_chunks}
    for name,case_file in [('v230','cases.json'),('v230_regression','regression-cases.json'),('v230_extension','extension-cases.json'),('v230_extra','extra-cases.json')]:
        traces={}
        for line in (RUN/'generated'/name/'cache/diagnostics.jsonl').read_text(encoding='utf8').splitlines():
            row=json.loads(line)
            if row.get('event')=='focused_answer':traces[row['request_id']]=row
        for case in read(RUN/case_file):
            trace=traces[case['id']]
            from types import SimpleNamespace
            core.retriever=SimpleNamespace(search=lambda *a,trace=trace,**k:([chunk_map[i] for i in trace['retrieval']['selected']],trace['retrieval']))
            try:
                with contextlib.redirect_stdout(io.StringIO()),contextlib.redirect_stderr(io.StringIO()):core.ask(case['question'])
            except Captured as caught:payload=caught.payload
            else:raise AssertionError('Expected intercepted generator/reviewer call')
            assert payload['context_limits']['total_evidence_tokens']==trace['context']['total_evidence_tokens'],(name,case['id'])
            assert set(trace['source_ids'])<={e['source_id'] for e in payload['evidence']}
            previous=all_answers[name][case['id']]
            from focused_context import search_queries
            revised=finish_answer(previous,search_queries(case['question'])[0],trace['source_ids'],payload['evidence'],core.docs)
            all_answers[name][case['id']]=revised
            replay.append({'system':name,'id':case['id'],'context_budget_matched':True,'changed':previous!=revised,
                'before_sha256':hashlib.sha256(previous.encode()).hexdigest(),'after_sha256':hashlib.sha256(revised.encode()).hexdigest()})
            if revised!=previous:changes.append({'system':name,'id':case['id'],'before':previous,'after':revised})
write(OUT/'replay.json',replay);write(OUT/'changes.json',changes);write(OUT/'all-answers.json',all_answers)
sys.path.insert(0,str(BASE/'v230-benchmark-code/benchmarks/platform_proxy'))
from compare_team_score import pair,TEAM_PROMPT
from run_v108_v228 import SharedRerank
from judge import aggregate
config=read(BASE/'platform-proxy-services.private.json')
assert hashlib.sha256(json.dumps(config,sort_keys=True).encode()).hexdigest()==read(RUN/'service-identity.json')['sha256']
shutil.copyfile(RUN/'service-identity.json',OUT/'service-identity.json')
shutil.copytree(RUN/'cache',OUT/'cache')
write(OUT/'freeze.json',{'parent_run_freeze_sha256':sha(RUN/'freeze.json'),'generation_package_sha256':sha(original),
    'final_package_sha256':sha(final),'finalizer_sha256':sha(Path(__file__)),'renderer_sha256':sha(REPO/'focused-rag/citation_labels.py'),
    'replay_rows':len(replay),'generation_unchanged_proof':'Only added citation_labels.py plus its import and one pure call after the completed review. Every other runtime file is byte-identical. All62 final contexts reconstructed from stored retrieval IDs with matching budgets.',
    'changes':[{k:c[k] for k in ['system','id']} for c in changes],
    'judge_prompt_sha256':hashlib.sha256(TEAM_PROMPT.encode()).hexdigest(),'limits':{'chat_calls':8,'rerank_calls':0}})
rows=read(RUN/'judgments.json')
api=SharedRerank(config,OUT,max_chat_calls=8,max_rerank_calls=0,max_chat_tokens=200000)
try:
    for change in changes:
        cohort=change['system'];ident=change['id']
        if cohort=='v230_regression':continue
        case_file={'v230':'cases.json','v230_extension':'extension-cases.json','v230_extra':'extra-cases.json'}[cohort]
        case=next(c for c in read(RUN/case_file) if c['id']==ident)
        if cohort=='v230':
            system='v230';baseline=read(RUN/'baseline.json')[ident]['value']['answer']
        else:
            suffix=cohort.removeprefix('v230_');system='v230_vs_v229_'+suffix;baseline=all_answers['v229_'+suffix][ident]
        data=[case['question'],case['golden'],baseline,change['after']]
        key=hashlib.sha256(json.dumps(data,ensure_ascii=False).encode()).hexdigest()
        result=pair(OUT,api,'content-'+key,*data)
        index=next(i for i,r in enumerate(rows) if r['system']==system and r['id']==ident)
        rows[index]={'system':system,'id':ident,**result}
        print(json.dumps({'rejudged_changed_text':ident,'score':result.get('score'),'status':result['status']}),flush=True)
finally:api.close()
write(OUT/'judgments.json',rows)
summary=read(RUN/'summary.json')
summary['initial_comparison']={k:summary[k] for k in ['systems','direct_comparisons']}
summary['systems']={n:{'aggregate':aggregate([r for r in rows if r['system']==n]),'fabrication_zeros':sum(r.get('fabrication_zero',False) for r in rows if r['system']==n)} for n in ['v229','v230']}
summary['direct_comparisons']={c:aggregate([r for r in rows if r['system']=='v230_vs_v229_'+c]) for c in ['extension','extra']}
done=[r for r in map(json.loads,(OUT/'calls.jsonl').read_text().splitlines()) if r['event']=='completed'] if (OUT/'calls.jsonl').exists() else []
usage={'deepseek_calls':len(done),'deepseek_tokens':sum(r.get('usage',{}).get('total_tokens',0) for r in done),'qwen_calls':0,'qwen_input_tokens':0,'api_errors':sum(r.get('status')!='ok' for r in done)}
summary['finalization']={'seconds':round(time.monotonic()-started,3),'replayed_rows':len(replay),'changed_rows':len(changes),'usage':usage,
 'scope':'No regeneration: pure citation/unused-template-section formatting replay after final review, on all62 saved v230 answers. Changed text judged in both orders; all unchanged judge inputs reused. Original full live run and its scores retained.'}
summary['total_usage']={k:summary['usage'].get(k,0)+usage.get(k,0) for k in summary['usage']}
write(OUT/'summary.json',summary)
print(json.dumps({'replayed':len(replay),'changed':len(changes),'systems':summary['systems'],'direct':summary['direct_comparisons'],'usage':summary['total_usage']},ensure_ascii=False),flush=True)
