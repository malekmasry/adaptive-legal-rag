"""Refresh final decision-selection diagnostics without model or network calls."""
import json,sys
from pathlib import Path
W=Path(__file__).resolve().parent
REPO=Path(r'C:\Users\USRBGDY\.codex\worktrees\psb-retriever35-v8\adaptive-legal-rag')
sys.path.insert(0,str(REPO/'focused-rag'))
from corpus import ingest
from decision_index import DecisionIndex
from decision_checks import checks
from answer_guides import plan_for
docs,_,_=ingest(W/'v230-comparison')
docs={d.id:d for d in docs};index=DecisionIndex(docs);rows=[]
for case in json.loads((W/'v230-extra-cases.json').read_text(encoding='utf8')):
    topics=plan_for(case['question'])['topics']
    evidence,trace=index.select(case['question'],topics,6000)
    rows.append({'id':case['id'],'topics':topics,'catalog':trace,'checks':checks(case['question'],evidence,docs,'2026-11-14')})
(W/'v230-offline-decision-audit.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print(json.dumps({'rows':len(rows),'purpose':'Final decision-index-only offline diagnostic; not full-context generation or a quality score.'}))
