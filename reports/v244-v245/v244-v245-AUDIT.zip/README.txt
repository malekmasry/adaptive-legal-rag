v244 / v245 frozen experiment audit

manifest.json maps logical paths to objects/<sha256>. Identical bytes are stored once.
Reconstruct only safe relative logical paths, verifying hashes; never write outside
your chosen destination. experiment/REPORT.html is the readable full comparison.
experiment/freeze.json fixes sources, packages, 30 known questions and v243 baseline.
All successful and failed attempts, caches and logs are preserved. source/ includes
frozen product code and tests. Private API configuration and BGE weights are absent.
The original runner retains Windows paths and is not a one-command portable install.

These are previously exposed regression questions, not an independent holdout.
50 means a tie with v243, not correctness or a predicted PSB score. The unchanged
two-order judge can contradict its own rationale. Raw results were not rerolled.
Runtimes use shared exact caches and are not cold platform latency comparisons.
v244 changes conditional retrieval; v245 changes only the final answer review.
The v243 platform reference 37.5/100 and 484 seconds is user-reported.
