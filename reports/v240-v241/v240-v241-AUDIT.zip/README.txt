PSB diagnostic experiment audit

manifest.json maps each logical path to objects/<sha256>; identical bytes are stored once.
Reconstruct by writing each referenced object to its logical path. Do not extract paths
outside your target directory. All paths in this archive are relative and traversal-free.

experiment/REPORT.html: readable answers, goldens, two-order judge results, context and spend.
experiment/selection.json: choice frozen before holdout.
experiment/generated/: full run captures and original execution artifacts.
experiment/review-continuations/ (where present): exact missing reviews, original draft reused.
experiment/calls.jsonl and caches: all paid requests, failures and exact cache reuse.
experiment/packages/: immutable product submission ZIPs for the variants of this experiment.
runner/: authoring, freeze, observer, recovery, analysis, packaging and test logs.
benchmark-code/: the unchanged benchmark implementation used for this run.

These are local pairwise results against a fresh v239 baseline, not platform scores.
18 development +12 holdout authored before runs. Same corpus/author is a limitation.
Any source-only oracle is diagnostic and cannot be deployed. Successful completed
answers were not regenerated during balance recovery. Timings use shared caches.
The v242/v243 experiment adds all three requested question-brief features. Its five
development UI-label cleanups were replayed exactly, without new generation; the
final v243 was then executed live on holdout. Raw v242 scores are retained.
Private API configuration and BGE model weights are intentionally not distributed.
Runners retain original workspace paths; adaptation and private service config are
needed on another machine. No submission or claim of 80/85 platform points is made.
